#include "functions.h"

void connect_client(int cl_socket, std::unordered_map<int, bool> &clients) {
	/* Clientul este deja inregistrat */
	if (clients.find(cl_socket) != clients.end()) {

		/* Clientul este inactiv */
		if (clients[cl_socket] == false) {
			clients[cl_socket] = true;
		}
		/* Clientul este activ */


	} else {
		/* Clientul nu este inregistrat => il inregistrez */
		clients[cl_socket] = true;
	}
}

void disconnect_client(int cl_socket, std::unordered_map<int, bool> &clients) {
	if (clients.find(cl_socket) != clients.end()) {
		if (clients[cl_socket] == true) {
			clients[cl_socket] = false;
		} else {
			fprintf(stderr, "Client is already disconnected");
		}
	} else {
		fprintf(stderr, "Client is not registered");
	}
}

void disconnect_all_clients(std::unordered_map<int, bool> &clients) {
	for (auto cl = clients.begin(); cl != clients.end(); cl++) {

		/* Deconectarea tuturor clientilor activi */
		if (cl->second == true) {
			disconnect_client(cl->first, clients);
		}

		/* Se trimite cerere de inchidere clientilor */
		char buffer[256];
		memset(buffer, 0, BUFLEN);
		strcpy(buffer, "exit");
		int res = send(cl->first, buffer, strlen(buffer), 0);
		close(cl->first);
	}
}