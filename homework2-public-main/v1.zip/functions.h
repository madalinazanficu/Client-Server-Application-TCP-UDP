#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H 1

#include <unordered_map>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include "helpers.h"
#include <iostream>
#include <netinet/tcp.h>

typedef struct client_t client_t;
struct client_t {
    int socket;
    char id[256];
    int count;
};

void connect_client(int cl_socket, std::unordered_map<int, bool> &clients);
void disconnect_client(int cl_socket, std::unordered_map<int, bool> &clients);
void disconnect_all_clients(std::unordered_map<int, bool> &clients);


#endif